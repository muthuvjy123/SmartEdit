﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'mk', {
	alt: 'Alternative Text', // MISSING
	btnUpload: 'Send it to the Server', // MISSING
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Image Info', // MISSING
	lockRatio: 'Lock Ratio', // MISSING
	menu: 'Image Properties', // MISSING
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Reset Size', // MISSING
	resizer: 'Click and drag to resize', // MISSING
	title: 'Image Properties', // MISSING
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Image source URL is missing.' // MISSING
} );
